# Python Utils
This repository contains wrapper functions and code snippets for the most common python dtypes. Truth is I'm tired of searching on Stack Overflow the same problems over and over again, so I am just gathering them here :)

### Installation
python_utils_tdinoto is OS independent and compatible with Python >= 3.7. 
To install it, ensure you have python installed and then run:
```python
python3 -m pip install python3_utils_tdinoto
```
